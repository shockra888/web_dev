function butti() {
    var name = document.getElementById("name").value;
    var clude = "Hello!!!";
    var last = "Have a nice day.";
    var spa = " ";
    document.getElementById("ans").innerHTML = clude + spa+ name + spa +last;
}